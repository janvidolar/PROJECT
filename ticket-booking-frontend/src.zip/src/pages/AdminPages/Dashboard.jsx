// // import { useState, useEffect } from "react";
// // import { Calendar, Clock, Users } from "lucide-react";
// // import { useNavigate } from "react-router-dom";
// // import BookingModal from "../../Components/BookingModal.jsx";
// // import getStatus from "../../Helper/getStatus.js";
// // import { ApiService } from "../../Services/ApiService.js";

// // const dashboardStats = [
// //     {
// //         id: 1,
// //         title: "Total Bookings",
// //         value: 2,
// //         bg: "bg-orange-50",
// //         iconBg: "bg-orange-500",
// //     },
// //     {
// //         id: 2,
// //         title: "Available Events",
// //         value: 4,
// //         tag: "Upcoming and Live",
// //         bg: "bg-purple-50",
// //         iconBg: "bg-purple-500",
// //     },
// // ];

 const Dashboard = () => {

// //     const navigate = useNavigate()
// //     const user = JSON.parse(localStorage.getItem('authDetail-tickethub'))
// //     const name = user.name.split(' ')[0]
// //     const id = user.id;

// //     const [events, setEvents] = useState([])
// //     const [open, setOpen] = useState(false);
// //     const [selectedEvent, setSelectedEvent] = useState(null);
// //     const [dashBoardStatasctics, setDashBoardStatistics] = useState(dashboardStats)

// //     const loadEvents = async () => {
// //         const res = await ApiService.post("/events/list", {})

// //         let status = "";
// //         let upcommingCount = 0
// //         let launchedCount = 0

// //         const formattedData = res.data.events.map((event) => {
// //             const isoDate = event.date
// //             const date = new Date(isoDate);
// //             const options = { month: "short", day: "2-digit", year: "numeric" };
// //             const formatted = date.toLocaleDateString("en-US", options);

// //             status = getStatus(event.date, event.time);
// //             if (status === "LIVE") launchedCount++;
// //             if (status === "UPCOMING") upcommingCount++;

// //             return { ...event, date: formatted }
// //         })

// //         setEvents(formattedData.slice(0, 3));

// //         const totalBookings = res?.data?.totalBookings
// //         const modifiedStats = dashBoardStatasctics.map((item) => {
// //             if (item.id == 1) {
// //                 return { ...item, value: totalBookings }
// //             }
// //             if (item.id == 2) {
// //                 return { ...item, value: launchedCount + upcommingCount }
// //             }
// //         })

// //         setDashBoardStatistics(modifiedStats)
// //     };

// //     useEffect(() => {
// //         loadEvents()
// //     }, [])

// //     const handleBooking = async (data) => {
// //         const payload = {
// //             eventId: data.id,
// //             userId: id,
// //             price: data.total,
// //             noOfTickets: data.ticketCount,
// //             seats: data.seats
// //         }

// //         const response = await ApiService.post("/tickets/add", payload)
// //         alert(response?.description)
// //         setOpen(false)
// //         loadEvents()
// //     }

   return (
      <h1>DashBoard</h1>
//         <>
 
// //             <div className="bg-gray-50 min-h-screen">
// //                 <div className="max-w- mx-auto px-4 sm:px-6 lg:px-8 py-8">

// //                     {/* Greeting Section */}
// //                     <div className="mb-10">
// //                         <h1 className="text-3xl font-bold text-gray-900">
// //                             Good day, {name}!
// //                         </h1>
// //                         <p className="text-gray-500 mt-1">
// //                             Here's what's happening with your bookings
// //                         </p>
// //                     </div>

// //                     {/* Stats Section */}
// //                     <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
// //                         {dashBoardStatasctics.map((stat) => (
// //                             <div
// //                                 key={stat.id}
// //                                 className={`p-6 rounded-2xl ${stat.bg} shadow-sm flex justify-between items-center`}
// //                             >
// //                                 <div className="w-full">
// //                                     <div className="flex justify-between items-center mb-4">
// //                                         <div className={`w-12 h-12 ${stat.iconBg} flex items-center justify-center rounded-xl`}>
// //                                             <Users size={20} />
// //                                         </div>
// //                                         {stat.tag && (
// //                                             <span className="text-xs font-semibold text-purple-600 bg-purple-100 px-3 py-1 rounded-full">
// //                                                 {stat.tag}
// //                                             </span>
// //                                         )}
// //                                     </div>
// //                                     <p className="text-gray-600 text-sm">{stat.title}</p>
// //                                     <h3 className="text-3xl font-bold mt-1">{stat.value}</h3>
// //                                 </div>
// //                             </div>
// //                         ))}
// //                     </div>

// //                     {/* Events Grid */}
// //                     <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
// //                         {events.map((event) => (
// //                             <div
// //                                 key={event.id}
// //                                 className="bg-white rounded-2xl p-6 shadow-sm"
// //                             >
// //                                 <h3 className="text-lg font-semibold mb-1">
// //                                     {event.title}
// //                                 </h3>

// //                                 <div className="space-y-3 text-sm text-gray-600">
// //                                     <div className="flex items-center gap-2">
// //                                         <Calendar size={16} /> {event.date}
// //                                     </div>
// //                                     <div className="flex items-center gap-2">
// //                                         <Clock size={16} /> {event.time}
// //                                     </div>
// //                                     <div className="flex items-center gap-2">
// //                                         <Users size={16} />
// //                                         {event.bookingCount}/{event.capacity} booked
// //                                     </div>
// //                                 </div>

// //                                 <button
// //                                     className="bg-orange-500 text-white px-6 py-2 rounded-full mt-6"
// //                                     onClick={() => {
// //                                         setSelectedEvent(event);
// //                                         setOpen(true);
// //                                     }}
// //                                 >
// //                                     Book Now
// //                                 </button>
// //                             </div>
// //                         ))}
// //                     </div>
// //                 </div>
// //             </div>

// //             {open && (
// //                 <BookingModal
// //                     event={selectedEvent}
// //                     isOpen={open}
// //                     onConfirm={handleBooking}
// //                     onClose={() => setOpen(false)}
// //                 />
// //             )}
// //         </>
);
};

export default Dashboard;
